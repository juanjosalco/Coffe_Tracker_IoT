import './CSS/index.css';
import './CSS/main.css';
import Home from './Views/Home';

function App() {
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
