import '../CSS/footer.css';

function Footer() {
  return (
    <footer>
        <img src="../Assets/logo blanco.svg" alt="logo blanco"/>
        <h3>Copyright ©2022</h3>
    </footer>
  );
}

export default Footer;






